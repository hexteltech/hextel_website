# Changelog

All notable changes to `@hasaan_6/rag-chatbot-widget` are documented in this file.

## [0.3.6] - 2026-11-22

### Added
- **Conversational Greeting & Small-Talk Support**: Added `isConversationalQuery` in `ragPipeline.ts` covering greetings, small talk (`"how are you"`, `"who are you"`, `"thanks"`, `"bye"`, `"assalamu alaikum"`), and multilingual greetings (`EN`, `PL`, `DE`, `ES`). Conversational messages now reach the LLM without requiring matching vector chunks or falsely triggering human handoff.
- **Multilingual Reply & Configurable Identity**: Added `botIdentity` and `customSystemPrompt` options to `RagPipelineConfig` and `RagPipelineStreamConfig`, and instructed the system prompt to always reply and generate follow-up suggestions in the user's detected language.
- **Gemini 3.x Model Support & Multi-Model Fallback**: Updated `createGeminiLLMAdapter` and `createGeminiLLMStream` to default to `gemini-3.5-flash-lite` (with `thinkingConfig: { thinkingLevel: "MINIMAL" }` and `thought: true` token filtering) and automatically fall back across `["gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-2.5-flash"]` on `404`, `429`, or `5xx` responses.
- **System Documentation**: Added a comprehensive `SYSTEM_DOCUMENTATION.md` detailing the Retrieval-Augmented Generation (RAG) concepts, mathematical cosine similarity equations, client-server proxy architecture, database schemas, and codebase walkthrough.
- **Word Document Report Generator**: Created a Python script `scripts/generate_report_docx.py` using `python-docx` to programmatically build a formatted Microsoft Word report (`SYSTEM_DOCUMENTATION.docx`) for academic review.

### Fixed
- **Lead Form Auto-Close on New Questions**: Fixed `ChatbotWidget.tsx` so `setLeadFormOpen(false)` runs when a new question is submitted and `setLeadFormOpen(Boolean(assistantMessage.needsHumanHandoff))` dynamically closes the lead capture form when subsequent questions do not require human handoff.
- **Self-Looping Suggested Questions**: Filtered out suggested follow-up questions that duplicate the user's current question in both synchronous and streaming RAG pipelines.

## [0.3.5] - 2026-07-02

### Fixed
- **Ternary Inversion Bug**: Fixed the streaming handoff ternary condition in `ChatbotWidget.tsx` to correctly display the fallback message (rather than a blank bubble) when zero search matches trigger the handoff form.
- **Typing Indicator UX overlap**: Restructured the loading check in `ChatWindow.tsx` to only render the typing indicator when the user is waiting for the initial server connection, immediately hiding the dots as soon as streaming tokens begin typing.
- **TypeScript Async Iterator compilation**: Added the `"lib": ["ES2020", "DOM"]` configuration to `tsconfig.json` to resolve missing global type definition warnings for `AsyncIterableIterator` on compilation.
- **Handoff Substring False-Positives**: Updated the handoff detection helper in `ragPipeline.ts` to utilize regex word boundary matches (`\b`), preventing false positive triggers on conversational vocabulary terms.

## [0.3.4] - 2026-07-01

### Added
- **API Rate-Limiting Backoffs**: Added `fetchWithRetry` helper inside `utils.ts` utilizing exponential retry backoffs, overriding the fetch scope across LLM/Embedding adapters and Supabase queries.
- **Client-Side Stream Recovery**: Configured the stream reader catch blocks to catch terminations mid-response, appending a connection warning indicator to the partial bubble rather than duplicating bubbles.
- **Hybrid Keyword fallback**: Programmed vector store adapters to trigger keyword ILIKE fallbacks automatically on vector search threshold misses, ranking matches by query term frequencies with full regex word boundary matching.

## [0.3.3] - 2026-07-01

### Added
- **Automated Test Suite**: Set up Vitest testing framework devDependencies and configured testing target scripts in `package.json`.
- **Vector Store Tests**: Created `vectorStores.test.ts` testing cosine similarity calculations and memory vector store sorting, filtering, and indexing limits.
- **RAG Pipeline Tests**: Created `ragPipeline.test.ts` testing synchronous prompt formatting and dynamic streaming event parsing (validating XML token stripping and metadata retrieval).

## [0.3.2] - 2026-07-01

### Added
- **Real-Time Token Streaming**: Added full Server-Sent Events (SSE) streaming capabilities to the RAG server pipeline. Exposes `runRagPipelineStream` returning a standard Web `ReadableStream`.
- **Streaming Adapters**: Implemented `createOpenAICompatibleLLMStream`, `createOpenAILLMStream`, and `createGeminiLLMStream` in `adapterFactories.ts` to fetch and parse live server-sent chunks.
- **Sliding-Window Token Parser**: Implemented a streaming text transformer `createStreamTransformer` in `ragPipeline.ts` that intercepts and buffers suggestions XML blocks mid-stream, delivering raw text tokens to the UI and a clean structured JSON metadata chunk at the very end of the connection.
- **Client-Side Stream Reader**: Updated `submitQuestion` in `ChatbotWidget.tsx` to read the streamed response body using reader buffers and update React messages state dynamically as tokens arrive.

## [0.3.1] - 2026-07-01

### Added
- **Chat History Persistence**: Added storage persistence configuration to the client widget. Users can pass the `persistence` prop (`"none" | "local" | "session"`) to keep chat logs synchronized to `localStorage` or `sessionStorage` and restored across page reloads.
- **SSR Safety**: Added server-side rendering execution guards to ensure memory storage sync is bypassed safely in Next.js/Remix SSR environments.

## [0.3.0] - 2026-07-01

### Added
- **Database Agnosticism**: Abstracted the vector database querying layer behind a flexible `VectorStoreAdapter` interface. This allows developers to plug in any custom database or third-party vector store (e.g. Pinecone, Qdrant, local memory list, custom Postgres pgvector instances).
- **Supabase Vector Store Adapter**: Added `createSupabaseVectorStore(url, anonKey)` in `vectorStores.ts` to retain seamless plug-and-play integrations with Supabase.
- **In-Memory Vector Store Adapter**: Added `createMemoryVectorStore(documents)` in `vectorStores.ts` providing an offline-capable, database-free matching adapter utilizing native cosine similarity calculations.
- **Similarity Math Helpers**: Added `cosineSimilarity(a, b)` for vector geometry processing in node and server environments.

### Changed
- **Breaking API Configuration**: Removed raw `supabaseUrl` and `supabaseAnonKey` parameters from the `runRagPipeline` configuration contract, replacing them with a structured `vectorStore` adapter interface.

## [0.2.9] - 2026-06-30

### Added
- **Dynamic Related/Follow-Up Questions**: Configured the RAG pipeline to instruct the LLM to output 2-3 relevant follow-up questions at the end of its response inside specific XML tags. Added a parser in `ragPipeline.ts` to extract and clean these questions from the raw answer.
- **Interactive Follow-Up Pills**: Updated `ChatWindow.tsx` to render these dynamic follow-up questions as clickable pills directly below the most recent assistant message. Clicking a pill automatically submits that question to the assistant.
- **Dynamic Suggestion Styles**: Added borders, backgrounds, and hover animations for `.chatbot-suggested-questions` and `.chatbot-suggested-question` inside `chatbot.css`.

### Changed
- **Type Consolidation**: Moved `DocumentChunk`, `RagPipelineConfig`, and `RagPipelineResult` definitions into the centralized `types.ts` module, updating imports in `ragPipeline.ts` to prevent duplicate type declarations.

## [0.2.8] - 2026-06-30

### Added
- **Clickable Hyperlink Citations**: Modified `MessageBubble.tsx` to render retrieved sources containing a `url` metadata attribute as active anchor `<a>` tags targeting `_blank`. Added hover micro-animations and styling for `.chatbot-source-link` inside `chatbot.css`.

### Changed
- **Conversational Tone & Persona**: Rewrote the RAG system prompt in `ragPipeline.ts` to instruct the LLM to adopt a friendly first-person persona representing Hasaan, explicitly block clinical prefaces like *"according to the context"*, and natively support greetings (e.g. "hi", "hello") without default fallback errors.

## [0.2.7] - 2026-06-30

### Added
- **Backend Email Notifications**: Added README guides showing developers how to handle lead captures securely on their server using webhooks (Discord/Slack) or email APIs (Resend/Nodemailer).
- **CSS Variable Definitions**: Listed all theme CSS variable names in the documentation to make it easy for developers to customize and override the widget branding colors inside their own websites.

### Changed
- **Documentation Overhaul**: Completely rewrote the `README.md` to document the secure proxy-architecture, separate client/server installation imports, and supply the corrected SQL index cast queries.

## [0.2.6] - 2026-06-30

### Added
- **Click-Outside-to-Close**: Configured a `useEffect` outside-click listener in `ChatbotWidget.tsx` to automatically collapse the chat window when a user clicks outside the chatbot widget shell.

### Changed
- **Styling Scoping**: Scoped all input fields in `LeadForm.tsx` to use `.chatbot-input-field` instead of the generic `.input-field` to prevent CSS style leaks to host pages.
- **Auto-Zoom Prevention**: Overrode mobile viewport input/select/textarea font-size to `16px` (`1rem`) to prevent iOS Safari/Android Chrome from automatically zooming in and shifting the page layout when the input is focused.
- **Scroll Chaining Fix**: Applied `overscroll-behavior: contain` to `.chatbot-body` and `.chatbot-window` in `chatbot.css` to prevent scroll events from propagating to the host portfolio page.
- **Text Clipping Fix**: Set `.chatbot-input` height to `100%` and `line-height` to `normal` inside `chatbot.css` to fix vertical layout issues that clipped letters and input placeholder text.

## [0.2.5] - 2026-06-30

### Fixed
- Updated `match_documents` SQL definition inside `supabaseSetup.ts` to perform explicit `halfvec(3072)` casts. This ensures the pgvector HNSW index is successfully matched and used by the PostgreSQL query planner instead of reverting to a full table sequential scan.

## [0.2.4] - 2026-06-30

### Added
- Dedicated backend RAG entrypoint `src/server.ts` that exports pipeline execution, ingestion functions, and model adapter factories.
- Centralized `src/types.ts` type module to prevent circular dependency cycles.
- Multi-target compile configuration in `tsup.config.ts` to separate client React code from Node server modules.

### Changed
- Refactored `ChatbotWidget.tsx` props to accept a safe, decoupled `chatEndpoint` parameter instead of loading private API keys and database credentials in the browser bundle.
- Replaced insecure context runtime UUID dependencies with a robust, browser-safe fallback UUID generator in `ChatbotWidget.tsx`.
- Refactored `index.ts` to export client-side only React components and properties.
- Removed the `useEffect` hook that reset chat history on parent re-renders.

## [0.2.3] - 2026-06-23

### Added

- **Quick Start** section in README: step-by-step setup from install → Supabase SQL → env vars → seed script → React component.
- "What you provide vs what the library handles" and "what requires code" tables for new users.

### Changed

- README main example now uses Gemini for both embedding and answers (`gemini-2.5-flash`).
- Default `createGeminiLLMAdapter` model updated to `gemini-2.5-flash` (replaces deprecated `gemini-1.5-flash`).

## [0.2.2] - 2026-06-23

### Changed

- Default `createGeminiLLMAdapter` model set to `gemini-2.5-flash`.

## [0.2.1] - 2026-06-23

### Fixed

- `SUPABASE_SETUP_SQL` now includes grants and RLS policy so the browser anon key can call `match_documents` and read `documents`. Without this, seeding works (service role) but the chatbot always shows the fallback message.

## [0.2.0] - 2026-06-23

### Changed

- **Breaking:** `SUPABASE_SETUP_SQL` now defaults to `vector(3072)` for `gemini-embedding-001` (Google deprecated `text-embedding-004`).
- Replaced IVFFlat index with HNSW on `halfvec(3072)` cast — pgvector indexes `vector` columns up to 2000 dimensions only; 3072 requires `halfvec` for indexing.
- Updated `createGeminiEmbeddingAdapter` JSDoc: `gemini-embedding-001` outputs **3072** dimensions by default (not 768).
- Updated README embedding dimension tables and database setup docs.
- Fixed JSDoc example in `EmbeddingAdapter` to use `gemini-embedding-001` instead of deprecated `text-embedding-004`.

### Migration

If you previously used `vector(768)` with `text-embedding-004`, you must:

1. Alter your Supabase `documents.embedding` column to `vector(3072)`.
2. Recreate `match_documents` with `query_embedding vector(3072)`.
3. Re-seed all documents with `createGeminiEmbeddingAdapter` (default 3072-dim output).

See README **Migrating from vector(768)** for example SQL.

## [0.1.2] - Previous release

- Initial published widget with Gemini, OpenAI, Cohere embedding factories and multi-provider LLM adapters.
- `SUPABASE_SETUP_SQL` used `vector(768)` for Gemini `text-embedding-004`.
